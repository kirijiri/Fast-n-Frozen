Copy these to C:\Program Files\Rainlendar\Languages
